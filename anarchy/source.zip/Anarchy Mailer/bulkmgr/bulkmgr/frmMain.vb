﻿Imports System.IO
Imports System.Net.Mail
Imports System.Threading
Public Class frmMain
    Public _active As Boolean = False
    Public _emails As List(Of String)
    Private Sub Form_Loadd(sender As Object, e As EventArgs) Handles MyBase.Load
        comboPort.SelectedIndex = 0
        comboType.SelectedIndex = 0
    End Sub

    Private Sub btnList_Click(sender As Object, e As EventArgs) Handles btnList.Click
        Dim _ofd As New OpenFileDialog

        _ofd.Filter = "Text File (*.txt)|*.txt"

        If _ofd.ShowDialog = DialogResult.OK Then
            txtList.Text = _ofd.FileName
            _import()
        End If
    End Sub

    Private Sub btnAttach_Click(sender As Object, e As EventArgs) Handles btnAttach.Click
        Dim _ofd As New OpenFileDialog

        _ofd.Filter = "Text File (*.txt)|*.txt|Word Document (*.docx)|*.docx|PDF File(*.pdf)|*.pdf|PowerPoint (*.pptx)|*.pptx|Excel Spreadsheet (*.xlsx)|*.xlsx|Jpeg Image (*.jpg)|*.jpg|Png Image (*.png)|*.png|Audio File (*.mp3)|*.mp3|Audio File(*.wav)|*.wav|Video File (*.mp4)|*.mp4|Compressed Folder (*.zip)|*.zip|Compressed Folder (*.rar)|*.rar|All Files (*.*)|*.*"

        If _ofd.ShowDialog = DialogResult.OK Then
            txtAttachment.Text = _ofd.FileName
        End If
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        txtAttachment.Text = ""
    End Sub

    Private Function _import()
        CheckForIllegalCrossThreadCalls = False
        Try
            Dim lines As String() = File.ReadAllLines(txtList.Text)
            _emails = lines.ToList()
        Catch ex As Exception
            MessageBox.Show("Critical error importing emails!", "Alert!")
            txtList.Text = ""
        End Try
    End Function

    Private Function _lock()

        txtEmail.ReadOnly = True
            txtPassword.ReadOnly = True
            chkShow.Enabled = False
            txtServer.ReadOnly = True
            chkSSL.Enabled = False
            comboPort.Enabled = False
            numDelay.ReadOnly = True
            btnList.Enabled = False
            txtSubject.ReadOnly = True
            comboType.Enabled = False
            txtBody.ReadOnly = True
            btnAttach.Enabled = False
            btnRemove.Enabled = False
            btnLaunch.Enabled = False
            btnCancel.Enabled = True
            MsgBox("locked")

    End Function

    Private Function _unlock()

        txtEmail.ReadOnly = False
        txtEmail.Text = ""
        txtPassword.ReadOnly = False
        txtPassword.Text = ""
        chkShow.Enabled = True
        chkShow.Checked = False
        txtServer.ReadOnly = False
        txtServer.Text = ""
        chkSSL.Enabled = True
        chkSSL.Checked = False
        comboPort.Enabled = True
        comboPort.SelectedIndex = 0
        numDelay.ReadOnly = False
        numDelay.Value = 100
        btnList.Enabled = True
        txtList.Text = ""
        txtSubject.ReadOnly = False
        txtSubject.Text = ""
        comboType.Enabled = True
        comboType.SelectedIndex = 0
        txtBody.ReadOnly = False
        txtBody.Text = ""
        btnAttach.Enabled = True
        btnRemove.Enabled = True
        txtAttachment.Text = ""
        txtSent.Text = "0"
        btnLaunch.Enabled = True
        btnCancel.Enabled = False
        _active = False

    End Function

    Private Sub btnLaunch_Click(sender As Object, e As EventArgs) Handles btnLaunch.Click
        If String.IsNullOrEmpty(txtEmail.Text) Then
            MessageBox.Show("Valid sender-email required!", "Alert!")
        ElseIf String.IsNullOrEmpty(txtPassword.Text) Then
            MessageBox.Show("Valid sender-email password required!", "Alert!")
        ElseIf String.IsNullOrEmpty(txtServer.Text) Then
            MessageBox.Show("SMTP relay server required!", "Alert!")
        ElseIf String.IsNullOrEmpty(txtList.Text) Then
            MessageBox.Show("You must select a valid email-list before conducting operation!", "Alert!")
        ElseIf String.IsNullOrEmpty(txtBody.Text) Then
            MessageBox.Show("A message body is required!", "Alert!")
        Else
            _active = True
            _lock()

            System.Threading.ThreadPool.QueueUserWorkItem(Sub() _worker())
        End If
    End Sub

    Private Sub _worker()
        CheckForIllegalCrossThreadCalls = False

        Dim _total As Integer = 0

        For Each _email As String In _emails
            If _active = False Then
                Exit For
            Else
                Try
                    Dim Smtp_Server As New SmtpClient
                    Dim e_mail As New MailMessage()
                    Smtp_Server.UseDefaultCredentials = False
                    Smtp_Server.Credentials = New Net.NetworkCredential(txtEmail.Text, txtPassword.Text)
                    Smtp_Server.Port = Int(comboPort.Text)

                    ' enable/display SSL encryption
                    If chkSSL.Checked = True Then
                        Smtp_Server.EnableSsl = True
                    Else
                        Smtp_Server.EnableSsl = False
                    End If

                    Smtp_Server.Host = txtServer.Text

                    e_mail = New MailMessage()
                    e_mail.From = New MailAddress(txtEmail.Text)
                    e_mail.To.Add(_email)
                    e_mail.Subject = txtSubject.Text

                    ' enable / disable HTML body message
                    If comboType.SelectedIndex = 0 Then
                        e_mail.IsBodyHtml = True
                    Else
                        e_mail.IsBodyHtml = False
                    End If

                    Dim bodyMsg As String = txtBody.Text

                    ' add optional attachment
                    If Not txtAttachment.Text = "" Then
                        Dim attachment As New Attachment(txtAttachment.Text)
                        e_mail.Attachments.Add(attachment)
                    End If

                    e_mail.Body = bodyMsg

                    ' send to inbox
                    Smtp_Server.Send(e_mail)

                    _total += 1
                    txtSent.Text = _total.ToString

                    MsgBox("Sent!")

                    Thread.Sleep(numDelay.Value)
                Catch e As Exception
                    'MsgBox(e.Message)
                End Try
            End If
        Next

        _unlock()
    End Sub

    Private Sub chkShow_CheckedChanged(sender As Object, e As EventArgs) Handles chkShow.CheckedChanged
        If chkShow.Checked = True Then
            txtPassword.UseSystemPasswordChar = False
        Else
            txtPassword.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        _active = False
        btnCancel.Enabled = False
    End Sub
End Class
