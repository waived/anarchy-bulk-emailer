﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.ClsNeoBuxTheme1 = New bulkmgr.clsNeoBuxTheme()
        Me.ClsControlMenu1 = New bulkmgr.clsControlMenu()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.txtSent = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.btnLaunch = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtAttachment = New System.Windows.Forms.TextBox()
        Me.comboType = New System.Windows.Forms.ComboBox()
        Me.btnAttach = New System.Windows.Forms.Button()
        Me.txtBody = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtSubject = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnList = New System.Windows.Forms.Button()
        Me.txtList = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtServer = New System.Windows.Forms.TextBox()
        Me.chkSSL = New System.Windows.Forms.CheckBox()
        Me.numDelay = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.comboPort = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.chkShow = New System.Windows.Forms.CheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ClsNeoBuxTheme1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.numDelay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ClsNeoBuxTheme1
        '
        Me.ClsNeoBuxTheme1.BackColor = System.Drawing.Color.White
        Me.ClsNeoBuxTheme1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.ClsNeoBuxTheme1.Controls.Add(Me.ClsControlMenu1)
        Me.ClsNeoBuxTheme1.Controls.Add(Me.GroupBox4)
        Me.ClsNeoBuxTheme1.Controls.Add(Me.GroupBox3)
        Me.ClsNeoBuxTheme1.Controls.Add(Me.GroupBox2)
        Me.ClsNeoBuxTheme1.Controls.Add(Me.GroupBox1)
        Me.ClsNeoBuxTheme1.Controls.Add(Me.PictureBox1)
        Me.ClsNeoBuxTheme1.Customization = "AAAA/w=="
        Me.ClsNeoBuxTheme1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ClsNeoBuxTheme1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ClsNeoBuxTheme1.Image = Nothing
        Me.ClsNeoBuxTheme1.Location = New System.Drawing.Point(0, 0)
        Me.ClsNeoBuxTheme1.Movable = True
        Me.ClsNeoBuxTheme1.Name = "ClsNeoBuxTheme1"
        Me.ClsNeoBuxTheme1.NoRounding = False
        Me.ClsNeoBuxTheme1.Sizable = False
        Me.ClsNeoBuxTheme1.Size = New System.Drawing.Size(639, 792)
        Me.ClsNeoBuxTheme1.SmartBounds = True
        Me.ClsNeoBuxTheme1.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.ClsNeoBuxTheme1.TabIndex = 0
        Me.ClsNeoBuxTheme1.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.ClsNeoBuxTheme1.Transparent = False
        '
        'ClsControlMenu1
        '
        Me.ClsControlMenu1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ClsControlMenu1.Customization = "8u/v/////wD///8A"
        Me.ClsControlMenu1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.ClsControlMenu1.Image = Nothing
        Me.ClsControlMenu1.Location = New System.Drawing.Point(566, 2)
        Me.ClsControlMenu1.Name = "ClsControlMenu1"
        Me.ClsControlMenu1.NoRounding = False
        Me.ClsControlMenu1.Size = New System.Drawing.Size(71, 19)
        Me.ClsControlMenu1.TabIndex = 14
        Me.ClsControlMenu1.Text = "ClsControlMenu1"
        Me.ClsControlMenu1.Transparent = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.txtSent)
        Me.GroupBox4.Controls.Add(Me.Label9)
        Me.GroupBox4.Controls.Add(Me.btnLaunch)
        Me.GroupBox4.Controls.Add(Me.btnCancel)
        Me.GroupBox4.Location = New System.Drawing.Point(397, 134)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(230, 136)
        Me.GroupBox4.TabIndex = 13
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "4. Manage"
        '
        'txtSent
        '
        Me.txtSent.BackColor = System.Drawing.Color.GhostWhite
        Me.txtSent.Location = New System.Drawing.Point(17, 97)
        Me.txtSent.Name = "txtSent"
        Me.txtSent.ReadOnly = True
        Me.txtSent.Size = New System.Drawing.Size(198, 23)
        Me.txtSent.TabIndex = 12
        Me.txtSent.Text = "0"
        Me.txtSent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(14, 79)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(56, 15)
        Me.Label9.TabIndex = 11
        Me.Label9.Text = "Delivered"
        '
        'btnLaunch
        '
        Me.btnLaunch.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnLaunch.Location = New System.Drawing.Point(17, 39)
        Me.btnLaunch.Name = "btnLaunch"
        Me.btnLaunch.Size = New System.Drawing.Size(95, 23)
        Me.btnLaunch.TabIndex = 14
        Me.btnLaunch.Text = "LAUNCH"
        Me.btnLaunch.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnCancel.Enabled = False
        Me.btnCancel.Location = New System.Drawing.Point(120, 39)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(95, 23)
        Me.btnCancel.TabIndex = 13
        Me.btnCancel.Text = "CANCEL"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btnRemove)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.txtAttachment)
        Me.GroupBox3.Controls.Add(Me.comboType)
        Me.GroupBox3.Controls.Add(Me.btnAttach)
        Me.GroupBox3.Controls.Add(Me.txtBody)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.txtSubject)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 346)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(615, 434)
        Me.GroupBox3.TabIndex = 12
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "3. Message"
        '
        'btnRemove
        '
        Me.btnRemove.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnRemove.Location = New System.Drawing.Point(108, 395)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(32, 23)
        Me.btnRemove.TabIndex = 16
        Me.btnRemove.Text = "X"
        Me.btnRemove.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(507, 21)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(77, 15)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Enable HTML"
        '
        'txtAttachment
        '
        Me.txtAttachment.BackColor = System.Drawing.Color.GhostWhite
        Me.txtAttachment.Location = New System.Drawing.Point(146, 395)
        Me.txtAttachment.Name = "txtAttachment"
        Me.txtAttachment.ReadOnly = True
        Me.txtAttachment.Size = New System.Drawing.Size(454, 23)
        Me.txtAttachment.TabIndex = 11
        '
        'comboType
        '
        Me.comboType.BackColor = System.Drawing.Color.GhostWhite
        Me.comboType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboType.FormattingEnabled = True
        Me.comboType.Items.AddRange(New Object() {"No", "Yes"})
        Me.comboType.Location = New System.Drawing.Point(510, 39)
        Me.comboType.Name = "comboType"
        Me.comboType.Size = New System.Drawing.Size(90, 23)
        Me.comboType.TabIndex = 11
        '
        'btnAttach
        '
        Me.btnAttach.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnAttach.Location = New System.Drawing.Point(16, 395)
        Me.btnAttach.Name = "btnAttach"
        Me.btnAttach.Size = New System.Drawing.Size(86, 23)
        Me.btnAttach.TabIndex = 15
        Me.btnAttach.Text = "Attachment"
        Me.btnAttach.UseVisualStyleBackColor = False
        '
        'txtBody
        '
        Me.txtBody.BackColor = System.Drawing.Color.GhostWhite
        Me.txtBody.Location = New System.Drawing.Point(16, 93)
        Me.txtBody.Multiline = True
        Me.txtBody.Name = "txtBody"
        Me.txtBody.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtBody.Size = New System.Drawing.Size(584, 296)
        Me.txtBody.TabIndex = 14
        Me.txtBody.WordWrap = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(13, 75)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(34, 15)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Body"
        '
        'txtSubject
        '
        Me.txtSubject.BackColor = System.Drawing.Color.GhostWhite
        Me.txtSubject.Location = New System.Drawing.Point(16, 39)
        Me.txtSubject.Name = "txtSubject"
        Me.txtSubject.Size = New System.Drawing.Size(485, 23)
        Me.txtSubject.TabIndex = 12
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(13, 21)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(46, 15)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Subject"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnList)
        Me.GroupBox2.Controls.Add(Me.txtList)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 277)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(615, 63)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "2. Mailing list"
        '
        'btnList
        '
        Me.btnList.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnList.Location = New System.Drawing.Point(16, 24)
        Me.btnList.Name = "btnList"
        Me.btnList.Size = New System.Drawing.Size(143, 23)
        Me.btnList.TabIndex = 4
        Me.btnList.Text = "Select your list"
        Me.btnList.UseVisualStyleBackColor = False
        '
        'txtList
        '
        Me.txtList.BackColor = System.Drawing.Color.GhostWhite
        Me.txtList.Location = New System.Drawing.Point(168, 24)
        Me.txtList.Name = "txtList"
        Me.txtList.ReadOnly = True
        Me.txtList.Size = New System.Drawing.Size(432, 23)
        Me.txtList.TabIndex = 11
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtPassword)
        Me.GroupBox1.Controls.Add(Me.txtServer)
        Me.GroupBox1.Controls.Add(Me.chkSSL)
        Me.GroupBox1.Controls.Add(Me.numDelay)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.comboPort)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.chkShow)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtEmail)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 134)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(370, 136)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "1. Email settings"
        '
        'txtPassword
        '
        Me.txtPassword.BackColor = System.Drawing.Color.GhostWhite
        Me.txtPassword.Location = New System.Drawing.Point(168, 40)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(188, 23)
        Me.txtPassword.TabIndex = 4
        Me.txtPassword.UseSystemPasswordChar = True
        '
        'txtServer
        '
        Me.txtServer.BackColor = System.Drawing.Color.GhostWhite
        Me.txtServer.Location = New System.Drawing.Point(16, 97)
        Me.txtServer.Name = "txtServer"
        Me.txtServer.Size = New System.Drawing.Size(143, 23)
        Me.txtServer.TabIndex = 7
        '
        'chkSSL
        '
        Me.chkSSL.AutoSize = True
        Me.chkSSL.Location = New System.Drawing.Point(115, 78)
        Me.chkSSL.Name = "chkSSL"
        Me.chkSSL.Size = New System.Drawing.Size(44, 19)
        Me.chkSSL.TabIndex = 12
        Me.chkSSL.Text = "SSL"
        Me.chkSSL.UseVisualStyleBackColor = True
        '
        'numDelay
        '
        Me.numDelay.BackColor = System.Drawing.Color.GhostWhite
        Me.numDelay.Location = New System.Drawing.Point(267, 97)
        Me.numDelay.Maximum = New Decimal(New Integer() {9999999, 0, 0, 0})
        Me.numDelay.Name = "numDelay"
        Me.numDelay.Size = New System.Drawing.Size(89, 23)
        Me.numDelay.TabIndex = 11
        Me.numDelay.Value = New Decimal(New Integer() {100, 0, 0, 0})
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(264, 79)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 15)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Delay M/s"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(165, 79)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 15)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Port"
        '
        'comboPort
        '
        Me.comboPort.BackColor = System.Drawing.Color.GhostWhite
        Me.comboPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboPort.FormattingEnabled = True
        Me.comboPort.Items.AddRange(New Object() {"587", "465", "25", "2525"})
        Me.comboPort.Location = New System.Drawing.Point(168, 97)
        Me.comboPort.Name = "comboPort"
        Me.comboPort.Size = New System.Drawing.Size(90, 23)
        Me.comboPort.TabIndex = 8
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(13, 79)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 15)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "SMTP Server"
        '
        'chkShow
        '
        Me.chkShow.AutoSize = True
        Me.chkShow.Location = New System.Drawing.Point(308, 22)
        Me.chkShow.Name = "chkShow"
        Me.chkShow.Size = New System.Drawing.Size(54, 19)
        Me.chkShow.TabIndex = 5
        Me.chkShow.Text = "show"
        Me.chkShow.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(165, 22)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 15)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Password"
        '
        'txtEmail
        '
        Me.txtEmail.BackColor = System.Drawing.Color.GhostWhite
        Me.txtEmail.Location = New System.Drawing.Point(16, 40)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(143, 23)
        Me.txtEmail.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(75, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Sender Email"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.bulkmgr.My.Resources.Resources.title
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox1.Location = New System.Drawing.Point(12, 45)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(615, 83)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(639, 792)
        Me.Controls.Add(Me.ClsNeoBuxTheme1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Anarchy 1.7  -  Bulk Emailer"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.ClsNeoBuxTheme1.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.numDelay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ClsNeoBuxTheme1 As clsNeoBuxTheme
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents comboPort As ComboBox
    Friend WithEvents txtServer As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents chkShow As CheckBox
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents btnList As Button
    Friend WithEvents txtList As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents ClsControlMenu1 As clsControlMenu
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents txtBody As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtSubject As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txtAttachment As TextBox
    Friend WithEvents comboType As ComboBox
    Friend WithEvents btnAttach As Button
    Friend WithEvents btnLaunch As Button
    Friend WithEvents Label9 As Label
    Friend WithEvents chkSSL As CheckBox
    Friend WithEvents numDelay As NumericUpDown
    Friend WithEvents txtSent As TextBox
    Friend WithEvents btnRemove As Button
    Friend WithEvents btnCancel As Button
End Class
